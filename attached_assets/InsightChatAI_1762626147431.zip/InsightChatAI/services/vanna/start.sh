#!/bin/bash
cd services/vanna
python vanna_service.py
