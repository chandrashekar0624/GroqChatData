import DashboardMetrics from '../DashboardMetrics'

export default function DashboardMetricsExample() {
  return <DashboardMetrics />
}
