import RevenueChart from '../RevenueChart'

export default function RevenueChartExample() {
  return <RevenueChart />
}
