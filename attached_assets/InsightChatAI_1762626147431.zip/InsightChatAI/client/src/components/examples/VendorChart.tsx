import VendorChart from '../VendorChart'

export default function VendorChartExample() {
  return <VendorChart />
}
